CREATE PROCEDURE proc1()
  begin
DECLARE i INT;
set i=1;

while i<=100
do
INSERT into user (account,name) VALUES
(CONCAT('账号',i),CONCAT('姓名',i));

set i=i+1;
end while;
commit;
end;
